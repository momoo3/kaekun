## 合成大西瓜

未修改版源码，可直接在浏览器运行

在线玩：[https://daxigua.liyupi.com](https://daxigua.liyupi.com)


### 本地启动

1. 安装 serve 工具：

    ```bash
    npm run serve
    ```

2. 进入 daxigua 目录，运行 serve：

    ```bash
    serve
    ```
   
3. 打开浏览器访问 localhost:5000 即可！
